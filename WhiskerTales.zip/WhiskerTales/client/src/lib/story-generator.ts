import { type InsertStory } from "@shared/schema";

// Function to generate a story based on the input parameters
export function generateStory({ childName, animal, theme }: { 
  childName: string;
  animal: string;
  theme: string;
}): InsertStory {
  // Capitalize first letter of each word
  const capitalizedAnimal = animal.charAt(0).toUpperCase() + animal.slice(1);
  const capitalizedTheme = theme.charAt(0).toUpperCase() + theme.slice(1);

  // Story structure with theme-based variations
  const storyIntro = `Once upon a time, in a magical forest filled with twinkling stars and whispering trees, there lived a young ${animal} named ${capitalizedAnimal} ${capitalizedTheme}heart. This special ${animal} had heard stories about a child named ${childName}, who was known throughout the forest for their incredible ${theme}.`;

  // Generate middle section based on theme
  const storyMiddle = generateThematicMiddle(childName, animal, theme);

  // Conclusion
  const storyEnd = `As the moon rose high in the sky, ${childName} and ${capitalizedAnimal} ${capitalizedTheme}heart knew they had learned something very special about ${theme}. From that day forward, whenever anyone in the magical forest spoke about ${theme}, they would remember the wonderful adventure of ${childName} and their friend ${capitalizedAnimal} ${capitalizedTheme}heart. And so, with hearts full of joy and new understanding, they knew this was just the beginning of many magical adventures to come.

The End.`;

  const fullStory = `${storyIntro}\n\n${storyMiddle}\n\n${storyEnd}`;

  // Calculate metadata
  const wordCount = fullStory.split(/\s+/).length;
  const readingTime = Math.ceil(wordCount / 200); // Assuming 200 words per minute reading speed

  // Generate SVG images for the story
  const animalImages = generateAnimalImages(animal, theme);

  return {
    childName,
    animal,
    theme,
    content: fullStory,
    metadata: {
      wordCount,
      readingTime,
      images: animalImages,
    },
  };
}

// Generate SVG animal images for the story
function generateAnimalImages(animal: string, theme: string) {
  // Return SVG images based on the animal type
  const animalSvgs = {
    lion: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="40" r="25" fill="#f3a953" /><circle cx="50" cy="40" r="18" fill="#f7c476" /><path d="M25 40 Q50 70 75 40" fill="none" stroke="#f3a953" stroke-width="5" /><circle cx="40" cy="35" r="3" fill="#333" /><circle cx="60" cy="35" r="3" fill="#333" /><path d="M45 47 Q50 52 55 47" fill="none" stroke="#333" stroke-width="2" /></svg>`,
    
    elephant: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><ellipse cx="50" cy="50" rx="30" ry="25" fill="#a0a0a8" /><path d="M20 40 Q10 30 10 45 Q10 60 20 55" fill="#a0a0a8" /><path d="M80 40 Q90 30 90 45 Q90 60 80 55" fill="#a0a0a8" /><path d="M50 75 L50 85" stroke="#a0a0a8" stroke-width="10" /><path d="M50 75 L40 85" stroke="#a0a0a8" stroke-width="10" /><path d="M50 75 L60 85" stroke="#a0a0a8" stroke-width="10" /><circle cx="40" cy="45" r="3" fill="#333" /><circle cx="60" cy="45" r="3" fill="#333" /></svg>`,
    
    giraffe: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M40 20 L50 5 L60 20" fill="#f8d878" stroke="#e8a030" stroke-width="2" /><rect x="45" y="20" width="10" height="50" fill="#f8d878" /><path d="M45 70 L40 95 M55 70 L60 95" fill="none" stroke="#f8d878" stroke-width="5" /><circle cx="45" cy="15" r="2" fill="#333" /><circle cx="55" cy="15" r="2" fill="#333" /><path d="M47 23 Q50 26 53 23" fill="none" stroke="#333" stroke-width="1" /><path d="M40 20 L60 20 L55 30 L45 30 Z" fill="#f8d878" stroke="#e8a030" stroke-width="1" /><path d="M45 40 L55 40 M45 50 L55 50" stroke="#e8a030" stroke-width="1" /></svg>`,
    
    penguin: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><ellipse cx="50" cy="60" rx="20" ry="30" fill="#222" /><ellipse cx="50" cy="60" rx="13" ry="25" fill="#f0f0f0" /><ellipse cx="50" cy="20" rx="15" ry="12" fill="#222" /><circle cx="45" cy="18" r="2" fill="#fff" /><circle cx="55" cy="18" r="2" fill="#fff" /><path d="M48 23 L52 23" stroke="#f86030" stroke-width="2" /><ellipse cx="30" cy="60" rx="8" ry="20" transform="rotate(-20, 30, 60)" fill="#222" /><ellipse cx="70" cy="60" rx="8" ry="20" transform="rotate(20, 70, 60)" fill="#222" /></svg>`,
    
    owl: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="30" fill="#a87c60" /><circle cx="35" cy="45" r="12" fill="#f0f0f0" /><circle cx="65" cy="45" r="12" fill="#f0f0f0" /><circle cx="35" cy="45" r="6" fill="#222" /><circle cx="65" cy="45" r="6" fill="#222" /><circle cx="35" cy="43" r="2" fill="#fff" /><circle cx="65" cy="43" r="2" fill="#fff" /><path d="M40 65 L60 65" stroke="#f86030" stroke-width="3" /><path d="M30 30 L20 15 M70 30 L80 15" stroke="#a87c60" stroke-width="3" /></svg>`,
    
    rabbit: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="60" r="25" fill="#f0f0f0" /><path d="M30 40 L30 10 Q30 5 35 10 L35 35" fill="#f0f0f0" /><path d="M70 40 L70 10 Q70 5 65 10 L65 35" fill="#f0f0f0" /><circle cx="42" cy="50" r="3" fill="#ff6b81" /><circle cx="58" cy="50" r="3" fill="#ff6b81" /><ellipse cx="50" cy="55" rx="2" ry="3" fill="#222" /><path d="M44 65 Q50 70 56 65" fill="none" stroke="#222" stroke-width="1" /></svg>`,
    
    bear: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="30" fill="#a87c60" /><circle cx="32" cy="35" r="8" fill="#7c5844" /><circle cx="68" cy="35" r="8" fill="#7c5844" /><circle cx="40" cy="50" r="3" fill="#222" /><circle cx="60" cy="50" r="3" fill="#222" /><ellipse cx="50" cy="60" rx="5" ry="3" fill="#222" /><path d="M40 70 Q50 75 60 70" fill="none" stroke="#7c5844" stroke-width="2" /></svg>`,
    
    fox: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M20 50 L50 20 L80 50 L65 80 L35 80 Z" fill="#f86030" /><path d="M35 80 L50 60 L65 80" fill="#fff" /><circle cx="40" cy="45" r="3" fill="#222" /><circle cx="60" cy="45" r="3" fill="#222" /><path d="M30 35 L20 20 M70 35 L80 20" stroke="#f86030" stroke-width="3" /><path d="M45 55 L50 60 L55 55" fill="none" stroke="#222" stroke-width="2" /></svg>`,
    
    dolphin: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M20 50 C30 40 50 30 70 40 C80 45 80 55 70 60 C50 70 30 65 20 50 Z" fill="#6b88c4" /><path d="M70 40 C80 30 90 35 85 45 C85 55 80 65 70 60" fill="#6b88c4" /><circle cx="35" cy="45" r="2" fill="#222" /><path d="M40 50 Q45 55 50 50" fill="none" stroke="#222" stroke-width="1" /><path d="M50 60 L60 55 L65 65" fill="#6b88c4" /></svg>`,
    
    turtle: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><ellipse cx="50" cy="50" rx="30" ry="25" fill="#619b64" stroke="#3c703e" stroke-width="2" /><circle cx="50" cy="50" r="15" fill="#7cc881" /><circle cx="35" cy="35" r="5" fill="#7cc881" /><circle cx="65" cy="35" r="5" fill="#7cc881" /><circle cx="35" cy="65" r="5" fill="#7cc881" /><circle cx="65" cy="65" r="5" fill="#7cc881" /><circle cx="25" cy="50" r="5" fill="#7cc881" /><circle cx="75" cy="50" r="5" fill="#7cc881" /><circle cx="40" cy="45" r="2" fill="#222" /><circle cx="60" cy="45" r="2" fill="#222" /><path d="M45 55 Q50 60 55 55" fill="none" stroke="#222" stroke-width="1" /></svg>`,
  };

  // Select the correct SVG based on the animal
  const svgData = animalSvgs[animal as keyof typeof animalSvgs] || animalSvgs.rabbit;
  
  // Create different image positions for the story
  return [
    {
      src: `data:image/svg+xml;utf8,${encodeURIComponent(svgData)}`,
      alt: `Illustration of ${animal} for the ${theme} story`,
      position: 1
    },
    {
      src: `data:image/svg+xml;utf8,${encodeURIComponent(svgData)}`,
      alt: `Another illustration of ${animal} for the ${theme} story`,
      position: 2
    }
  ];
}

function generateThematicMiddle(childName: string, animal: string, theme: string): string {
  const capitalizedAnimal = animal.charAt(0).toUpperCase() + animal.slice(1);
  
  const themeStories: Record<string, string> = {
    kindness: `One day, ${childName} came across ${capitalizedAnimal} ${theme}heart who was helping a small mouse carry seeds to its home. The little mouse had gathered too many seeds and couldn't carry them all. Without hesitation, ${capitalizedAnimal} ${theme}heart had offered to help, even though many other animals had simply walked past. ${childName} was touched by this simple act of kindness and joined in helping the mouse family.

Together, ${childName} and ${capitalizedAnimal} ${theme}heart spent the afternoon helping various forest creatures with their tasks. They helped a family of birds rebuild their nest after a storm, assisted elderly rabbits in gathering fresh vegetables, and even taught young squirrels how to properly sort and store their acorns for winter.

Through their actions, they discovered that kindness was like magic - it had the power to transform any situation and bring smiles to everyone's faces. The forest seemed to glow a little brighter with each kind deed they performed.`,

    friendship: `One rainy afternoon, ${childName} discovered ${capitalizedAnimal} ${theme}heart sitting alone under a large mushroom, looking rather sad. It turned out that ${capitalizedAnimal} ${theme}heart was new to the forest and hadn't made any friends yet. ${childName} knew exactly how it felt to be the new one somewhere.

${childName} invited ${capitalizedAnimal} ${theme}heart to join them for an adventure, and together they explored the magical forest, sharing stories and laughs along the way. They discovered they both loved cloud-watching, making daisy chains, and singing silly songs in the rain.

As they adventured together, other forest animals joined their merry group. A wise old owl taught them forest secrets, a playful squirrel showed them the best climbing trees, and a gentle deer introduced them to the sweetest berry patches. Through these shared experiences, ${childName} and ${capitalizedAnimal} ${theme}heart learned that true friendship grows stronger with every shared moment.`,

    courage: `During a particularly stormy night, ${childName} and ${capitalizedAnimal} ${theme}heart heard crying coming from the Dark Hollow - a part of the forest that most animals avoided. Despite their fear, they knew someone needed help.

Gathering their courage, they ventured into the Dark Hollow, holding paws and supporting each other. Their hearts were pounding, but they kept going. They discovered a baby fox who had gotten lost in the storm.

Using their combined bravery, ${childName} and ${capitalizedAnimal} ${theme}heart faced their fears of the dark and the storm to guide the baby fox back home. Along the way, they realized that being brave didn't mean not being scared - it meant doing what was right even when you were afraid.`,

    sharing: `${capitalizedAnimal} ${theme}heart had discovered a magnificent apple tree full of the juiciest apples anyone had ever seen. At first, they thought about keeping it a secret, but then they remembered seeing some hungry animals in the forest.

${childName} and ${capitalizedAnimal} ${theme}heart worked together to organize a grand forest feast. They invited every animal they knew, and everyone brought something to share. The bears brought honey, the squirrels brought nuts, and the rabbits brought fresh vegetables from their gardens.

What started as one animal's discovery turned into a wonderful celebration of sharing, where everyone contributed what they could. The feast became a regular forest tradition, and all the animals learned that sharing not only meant giving something away but also receiving the joy of community in return.`,

    honesty: `One day, while playing catch with a golden acorn, ${capitalizedAnimal} ${theme}heart accidentally broke Wise Owl's favorite reading glasses. Scared of getting in trouble, they thought about hiding what happened.

But ${childName} helped ${capitalizedAnimal} ${theme}heart understand that being honest, even when it's difficult, is always the best choice. Together, they went to Wise Owl and told the truth about what happened.

To their surprise, Wise Owl wasn't angry at all. Instead, they were proud of ${capitalizedAnimal} ${theme}heart for being honest. The owl shared a story about a time when they too had made a mistake and learned the importance of telling the truth. This experience taught everyone in the forest that honesty builds trust and makes friendships stronger.`,

    patience: `${capitalizedAnimal} ${theme}heart was known for wanting everything to happen right away. They couldn't wait for flowers to bloom or for berries to ripen, always trying to rush things along.

${childName} showed ${capitalizedAnimal} ${theme}heart the joy of watching a butterfly emerge from its chrysalis. Day by day, they observed the slow but magical transformation. While waiting, they learned to appreciate the small changes happening around them - the gradual changing of leaves' colors, the slow growth of mushrooms, and the careful construction of a spider's web.

Through their observations, they discovered that the best things in life take time, and waiting patiently can make the end result even more special. They learned to find joy in the journey, not just the destination.`,

    responsibility: `${capitalizedAnimal} ${theme}heart was given an important job by the Forest Council - to care for a patch of magical moonflowers that helped light the forest at night. At first, it seemed like too big a task, but ${childName} offered to help create a schedule and share the work.

Together, they learned about the needs of the moonflowers - how much water they needed, when to trim their leaves, and how to protect them from frost. They never missed a day of care, even when it was raining or they felt tired.

Other animals noticed their dedication and started helping too. Soon, the moonflower patch grew bigger and brighter than ever before, lighting up the entire forest at night. Through this experience, everyone learned that being responsible meant not just doing what was expected, but doing it with care and commitment.`,
  };

  return themeStories[theme] || `One magical day, ${childName} and ${capitalizedAnimal} ${theme}heart went on an adventure together. They learned many important lessons about ${theme} and discovered that the most magical moments happen when we share them with friends.`;
}
